#!/bin/bash

# Backup direktori /home/user/data ke /backup
NOW=$(date +"%Y-%m-%d_%H-%M-%S")
SOURCE="/home/user/data"
DEST="/home/user/backup/data_$NOW.tar.gz"

tar -czvf "$DEST" "$SOURCE"
echo "Backup selesai: $DEST"

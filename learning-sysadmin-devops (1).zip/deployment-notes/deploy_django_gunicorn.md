# 🚀 Deploy Django + Gunicorn + Nginx (Manual)

1. **Install dependencies:**
   ```bash
   pip install gunicorn
   ```

2. **Run Gunicorn manually:**
   ```bash
   gunicorn projectname.wsgi:application --bind 0.0.0.0:8000
   ```

3. **Setup Nginx as reverse proxy** using `nginx-default.conf`.

4. **Restart Nginx:**
   ```bash
   sudo systemctl restart nginx
   ```

5. **(Opsional)** Buat service systemd untuk Gunicorn agar otomatis jalan saat boot.

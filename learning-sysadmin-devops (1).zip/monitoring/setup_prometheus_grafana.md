# 📊 Setup Monitoring: Prometheus + Grafana

## Prometheus
1. Download Prometheus dari [prometheus.io](https://prometheus.io/download/)
2. Buat file `prometheus.yml` dan jalankan:
   ```bash
   ./prometheus --config.file=prometheus.yml
   ```

## Grafana
1. Install Grafana:
   ```bash
   sudo apt install -y grafana
   ```

2. Jalankan:
   ```bash
   sudo systemctl start grafana-server
   ```

3. Akses di browser: `http://localhost:3000`

# 👨‍💻 Learning Sysadmin & DevOps – Personal Portfolio

Halo! Saya [Nama Kamu], saat ini saya sedang transisi dari QA Manual ke bidang System Administrator dan DevOps.  
Repositori ini saya buat sebagai dokumentasi hasil belajar, eksplorasi teknologi, dan eksperimen mandiri.

## 🧰 Topik yang saya pelajari:

- Docker & Docker Compose
- Gunicorn + Nginx Deployment
- Dasar Monitoring (Prometheus & Grafana)
- Automation dengan Bash Script
- Dasar Manajemen Server Linux

---

## 📁 Isi Repositori

| Folder              | Deskripsi                                                             |
|---------------------|----------------------------------------------------------------------|
| `docker/`           | Contoh file `docker-compose.yml` untuk local testing                 |
| `nginx/`            | Contoh konfigurasi Nginx reverse proxy                               |
| `deployment-notes/` | Langkah manual deploy Django menggunakan Gunicorn                    |
| `monitoring/`       | Instalasi dasar Prometheus + Grafana                                 |
| `automation/`       | Skrip bash sederhana untuk backup dan cron task                      |
| `certifications/`   | Sertifikat kursus yang saya ikuti (akan ditambahkan)                 |

---

## 🚀 Rencana Selanjutnya

- Membuat setup Ansible sederhana untuk provisioning server
- Latihan CI/CD dasar (GitHub Actions)
- Menyusun portofolio deployment di VPS (jika memungkinkan)

---

Terima kasih telah melihat portofolio saya 🙏  
Saya sangat terbuka untuk masukan, kolaborasi, atau feedback dari tim PT CSD!
